// lectores_escritores.h
// Libreria generica que contiene las funciones necesarias para simular el comportamiento de los hilos de escritura y lectura
// Garcia Gonzalez Aaron Antonio
// Sistemas Operativos 2CM9


FILE * baseDatos; // Apuntador a archivo, se utilizara para tener acceso a la base de datos en las siguientes funciones
// Funcion que modifica el archivo, para añadir lo que el usuario teclee en la entrada estandar, esta funcion es utilizada por los escritores
void escribirenbasedatos(){
	char c;
	baseDatos=fopen("baseDatos.txt","a+");

	while ((c=getc(stdin))!='\n'){
		fputc(c,baseDatos);
	}
	fputc(' ',baseDatos);
	fclose(baseDatos);	
	sleep(1);
}

// Funcion que lee un archivo, y muestra caracter a caracter el contenido del mismo
void leerenbasedatos(){
	sleep(1);
	baseDatos=fopen("baseDatos.txt","r");
	char a;
	while (!feof(baseDatos)){
		fscanf(baseDatos,"%c",&a);
		printf("%c",a);
	}
	printf("\n");
	fclose(baseDatos);
}

// Funcion que simula el comportamiento de un escritor, la cual recibe como argumento el identificador del hilo escritor que la llama, cada que entra, bloqueara el uso de la base de datos, e inmediatamente al temrinar de escribir en el archivo mediante la funcion escribirBD, liberara a la base de datos por si algun lector o esccritor requeiere el acceso
void *escritor(void *p){
		extern sem_t db;
		int *id_es;
        id_es=(int *)p;

		sem_wait(&db);
		printf("\nEscritor %d Escribiendo...\n",*id_es);
		escribirenbasedatos();
		sem_post(&db);
		pthread_exit(NULL);

}

// Funcio nque simula el comportameinto de un lector, la cual recibe como argumento el identificador del hilo lector que la llama
void *lector(void *p){
		extern sem_t mutex,db; 
		extern int rc;
		int *id_le;
        id_le=(int *)p;
		
		sem_wait(&mutex); // Aqui se comienza a hacer uso de los datos incluidos en la region critica ...(1)
		rc++;
		if(rc == 1) // Unicamente el primer lector que empieza a leeer, es quier bloquera la base de datos, haciendo uso de un down 
		   sem_wait(&db); 
		sem_post(&mutex); // Aqui se deja de hacer uso de los datos includios en la region critaca ...(1)
		
		printf("\nLector %d Leyendo...\n",*id_le);
		leerenbasedatos();
		sem_wait(&mutex); // Aqui se comienza a hacer uso de nuevo de los datos incluidos en la region critica ...(2)
		rc--;

		if(rc == 0) // Uncamente el ultimo lector que este leyendo la base de datos, podra desbloquear la bd
		  sem_post(&db);

		sem_post(&mutex); // Aqui se deja d ehacer uso de los datos incluidos en la region critica ...(2)
		pthread_exit(NULL);
}