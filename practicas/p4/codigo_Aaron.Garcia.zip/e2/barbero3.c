#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <dispatch/dispatch.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>

void * funcion_barbero(void *idp);
void * funcion_cliente(void *idp);
void servicio_cliente();
void * hacer_corte();
    
// Mutex // 
pthread_mutex_t hs_mutex;

// Semaforos //
dispatch_semaphore_t s_barbero_listo; 
dispatch_semaphore_t s_cliente_listo;
dispatch_semaphore_t s_modificar_asientos;

// Entradas
int total_sillas;
int total_clientes;

int sillas_disponibles;
int clientes_no_atendidos = 0;
time_t tiempo_espera;

void * funcion_barbero(void *idp){    
    int contador = 0;
    
    while(1){
        // Bloquear el semáforo "s_cliente_listo" - intenta conseguir un cliente o dormir si no hay ninguno
        dispatch_semaphore_wait(s_cliente_listo,DISPATCH_TIME_FOREVER);

        // Bloquear el semáforo "s_modificar_asientos" - intentar obtener acceso a los asientos
        dispatch_semaphore_wait(s_modificar_asientos,DISPATCH_TIME_FOREVER);

        // Incrementar en 1 los asientos disponibles
        sillas_disponibles++;

        // esbloquear semáforo "s_modificar_asientos
        dispatch_semaphore_signal(s_modificar_asientos);

        // Desbloquear el semáforo "s_barbero_listo" - establecer barbero listo para hacer otro corte
        dispatch_semaphore_signal(s_barbero_listo);        

        // Bloquea mutex "hs_mutex - protege el servicio del mismo barbero de otros hilos
        pthread_mutex_lock(&hs_mutex);

        // Serivicio al cliente //
        servicio_cliente();    

        // Desbloquear mutex "hs_mutex - corte finalizado 
        pthread_mutex_unlock(&hs_mutex);
        
        printf("Cliente atendido.\n");
        contador++; 
        if(contador == (total_clientes - clientes_no_atendidos))
            break;

    }
    pthread_exit(NULL);    
}

void * funcion_cliente(void *idp){  
    int id_cliente=*(int *)idp;
    struct timeval inicio, parar;
     
    // Bloquer el semáforo "s_modificar_asientos
    dispatch_semaphore_wait(s_modificar_asientos,DISPATCH_TIME_FOREVER); 

    // Si hay un asiento disponible, entonces
    if(sillas_disponibles >= 1){
        // Ocupar asiento
        sillas_disponibles--;

        printf("Cliente [%d] > esta esperando.\n", id_cliente);
        printf("\tSillas disponibles: %d\n", sillas_disponibles);
        
        // Iniciar contador de tiempo de espera 
        gettimeofday(&inicio, NULL);
           
        // Desbloquear semáforo "s_cliente_listo" - configurar el cliente listo para ser atendido
        dispatch_semaphore_signal(s_cliente_listo);

        // Desbloquear semáforo "s_modificar_asientos"
        dispatch_semaphore_signal(s_modificar_asientos);         

        // Bloquear semáforo "s_barbero_listo" - esperar a que el barbero se prepare 
        dispatch_semaphore_wait(s_barbero_listo,DISPATCH_TIME_FOREVER); 

        // detener el contador de tiempo de espera
        gettimeofday(&parar, NULL);
        
        double sec = (double)(parar.tv_usec - inicio.tv_usec) / 1000000 + (double)(parar.tv_sec - inicio.tv_sec);
        
        // Asignación del tiempo dedicado a la variable global (ms)
        tiempo_espera += 1000 * sec;
        printf("Cliente [%d] > está siendo atendido. \n", id_cliente);        
    }
    else{
        // Desbloquear semáforo "s_modificar_asientos"
        dispatch_semaphore_signal(s_modificar_asientos);
        clientes_no_atendidos++;
        printf("Un cliente se fue.\n");
    }
    pthread_exit(NULL);
}

void servicio_cliente(){

    int s = rand() % 999; // Numero random entre 0 y 998 (milisegundos) 

    s = s * 1000; // Convertir de milisegundos a microsegundos 
    usleep(s);
}

void * hacer_corte(){
    int tmp;   
    int contador = 0;
    int id_cliente = 1;

    while(contador < total_clientes)
    {
        // Declarar y crear hilo cliente 
        pthread_t h_cliente;
        tmp = pthread_create(&h_cliente, NULL, (void *)funcion_cliente, &id_cliente);  
        if(tmp)
            printf("Error en crear hilo.");
        
        // Incrementar el contador 
        id_cliente++;
        contador++;
            
        // Dormir por 100ms antes de crear otro cliente 
        usleep(100000);
    }
    pthread_exit(NULL);
}

int main(int argc, char const *argv[]){
    srand(time(NULL));  

    // Hilo de unico barbero 
    pthread_t barbero_1;

    // Hilo que crea clientes 
    pthread_t h_crea_cliente;

    int tmp;

    // Incializar mutex 
    pthread_mutex_init(&hs_mutex, NULL);

    // Incializar semaforos

    s_cliente_listo = dispatch_semaphore_create(0);
    s_barbero_listo = dispatch_semaphore_create(0);
    s_modificar_asientos = dispatch_semaphore_create(1); 
    
    printf("Teclee el numero de sillas de espera: : \n");
    scanf("%d", &total_sillas);
    
    printf("Teclee el numero de clientes: \n");
    scanf("%d", &total_clientes);
    
    sillas_disponibles = total_sillas; 
    
    // Crear hilo del barbero
    tmp = pthread_create(&barbero_1, NULL, (void *)funcion_barbero, NULL);  
    if(tmp)
        printf("Error al crear hilo"); 
    
    // Crear hilo h_crea_cliente
    tmp = pthread_create(&h_crea_cliente, NULL, (void *)hacer_corte, NULL);  
    if(tmp)
        printf("Error al crear hilo"); 
     
    // Espera a que los hilos terminen 
    pthread_join(barbero_1, NULL);
    pthread_join(h_crea_cliente, NULL);
        
    printf("\n------------------------------------------------\n");
    printf("Promedio de tiempo de espera de los clientes: %f ms.\n", (tiempo_espera / (double) (total_clientes - clientes_no_atendidos)));
    printf("Número de clientes que no obtuvieron un corte: %d\n", clientes_no_atendidos);    	
}