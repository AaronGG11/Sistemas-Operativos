// Para pilas

typedef  char Elem;

void ImpElem(Elem e){
	putchar(e);
	//printf("");
}
