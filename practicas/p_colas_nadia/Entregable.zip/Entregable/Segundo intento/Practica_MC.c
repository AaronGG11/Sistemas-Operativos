/*
Autor: Nadia Beatriz Lopez Aguilar
Fecha: 25 de septiembre del 2019
Descripción: Menù para uso colas de mensajes para diferentes procesos.
Entrada: ------------------------
Salida:
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>

#define TAM 10
int main(){
    char *cola, elemento; //arreglo de chars | caracter a leer del teclado
    int shmid, shmid1, opc, *cont; //variable de la id de la memoria compartida y del apuntador a los elementos
    key_t llave, llave1; //llaves a usar

    llave=ftok("/bin/pwd",30); //obtener la llave
    if(llave==-1){
        perror("\nError en ftok");
        exit(-1);
    }

    llave1=ftok("/bin/pwd",40); //obtener segunda llave para el contador
    if(llave1==-1){
        perror("\nError en ftok");
        exit(-1);
    }

    shmid=shmget(llave,TAM*sizeof(char),IPC_CREAT|0777);//crear la memoria compartida;
    if(shmid==-1){
        perror("\nError en shmget");
        exit(-1);
    }

    shmid1=shmget(llave1,sizeof(int),IPC_CREAT|0777);//crear la memoria compartida;
    if(shmid==-1){
        perror("\nError en shmget");
        exit(-1);
    }

    cola=shmat(shmid,0,0); //introducimos la cadena en la memoria
    cont=(int *) shmat(shmid1,0,0);

    while(1){ //creacion del menu
        printf("\nIntroduce una opcion:\n\t1.Ingresar elemento.\n\t2.Eliminar elemento.\n\t3.Visualizar\n\t4.Finalizar.\n\tOpcion:\t");
        scanf("%i", &opc);
        switch(opc){
            case 1:
                if(*cont>9){
                 printf("\nError, memoria llena. Extraiga un elemento de la memoria\n");
                }else{
                printf("\nIntroduce el valor:");
                scanf(" %c", &elemento);
                cola[*cont]=elemento;
                *cont=*cont+1;
                }
                break;
            case 2:
                if(cont==0){
                    printf("\nError, no hay elementos para eliminar.\n");
                }else{
                    printf("\nElemento a eliminar:%c", cola[*cont-1]);
                    cola[*cont-1]='\0';
                    *cont=*cont-1;
                    printf("\nElemento eliminado.");
                }
                break;
            case 3:
                printf("\nLo que existe en la memoria es:\n");
                for(int i=*cont-1; i>=0; i--){
                    printf("Pocision de la memoria %d --> %c\n", i, cola[i]);
                }
                break;
	    case 4:
                printf("\nFinalizar\n");
                shmdt(cola); //desasociar la memoria compartida
                shmctl(shmid,IPC_RMID,0);//liberar memoria compartida -->en el segundo argumento como no tenemos una estructura le ponemos cero.
                exit(0);
	            break;
            default:
                printf("\nOpcion incorrecta %i",opc);
                break;

        }

    }

}

