/*
 Autor:		Aarón Antonio Garcia Gonzalez
 Fecha:		26 de Noviembre de 2019
 Descripción:	Programa que simula un mini bash 
 Entrada:	-
 Salida:	-
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

// Variables globales
#define READ  0
#define WRITE 1
#define MAX_LIMIT 80

static int run(char* cmd, int input, int first, int last);
static void parse(char* cmd);
static int command(int input, int first, int last);
static char* saltarEspacio(char* s);
void sigint_handler(int sig);
void child_exit();
static int command(int input, int first, int last);
static void waitEnd();

static char* myargv[MAX_LIMIT];
pid_t pid;
int command_pipe[2]; // Para operaciones de tuberías.
int isInDir = 0; // <
int isOutDir = 0; // >
int rPos, lPos; // x ><
static char line[80];// el comando de entrada
static int fgProc = 0;

int main(int argc, char const *argv[]){
	printf("Teclee [help] para obtener ayuda sobre cómo usar el shell\n");
    signal(SIGINT, sigint_handler); // controlador de señal para Ctrl + C
	signal (SIGCHLD, child_exit); // Envia la señal de que su proceso hijo ha terminado y ejecuta la funcion
	// SIGCHLD proceso hijo termiando o parado 
	while (1) { // Bucle infinito del programa
		printf("Aaron-mini-bash> "); /* Mostrar el command prompt */
		fflush(NULL);
		if (!fgets(line, MAX_LIMIT, stdin)) // si la linea es valida, se lee
			return 0;

		isOutDir = 0;
		rPos = -1;
		isInDir = 0;
		lPos = -1;
		int input = 0;
		int first = 1;
		char* cmd = line; // copiamos nuestra linea en cmd
		char* next = strchr(cmd, '|'); // Localiza la primera aparición de |, como apuntador
		while (next != NULL){ // entra si por lo menos hay un '|' en el cmd
			/* 'next' apunta a '|' */
			*next = '\0'; // cambiamos el valor de | a espacio
			input = run(cmd, input, first, 0); // input -> stdin, primer caso , 0 -> bandera que dice que no es el ultimo dentro de la tuberia
			cmd = next + 1;
			next = strchr(cmd, '|'); /* Encontrar siguiente '|' */
			first = 0; // bandera que indica que ya se ha leido por lo menos una instruccion
		}
		input = run(cmd, input, first, 1);
		waitEnd(); // espere a que todo el proceso en primer plano complete la ejecución.
		fgProc=0; // En este punto, todo el proceso de primer plano se ha completado, debido a nuestra llamada de espera.
	}
	return 0;
}

static int run(char* cmd, int input, int first, int last){
	int toReturn, count = 0;
	parse(cmd);
	if (myargv[0] != NULL) { // si no es ultimo comando (comando)
        if (strcmp(myargv[0], "exit") == 0){
            exit(0);
        }
        if (strcmp(myargv[0], "help") == 0){
            printf("Welcome to mini shell!\n");
            printf("The shell supports standard unix/ linux shell commands\n");
            printf("To execute a command use the following syntax\n >command [args]* [ | commmand [args]* ]* \n ex. \nmini-shell>ls -l | wc\n\n");
            printf("Certain inbuilt commands:\n");
            printf("cd : changes the directory to the said directory, provided it exists.\n Syntax cd <directory path> \n ex. \nmini-shell>cd newDir\n\n");
            printf("exit : Exits from mini-shell. You can do the same using the Ctrl+c signal.\n ex. \nmini-shell>exit\n\n");
            printf("last [n] : prints the last n commands entered into the shell. If called without n, prints all the commands executed till that point in time.\n");
            printf("ex: last 4 -> to print the last 4 commands OR last -> to print all the commands that were entered.\n");
            return 0;
        }
        if(strcmp(myargv[0], "cd") == 0){
            if(chdir(myargv[1]) != 0){ // chdir - cambia el directorio de trabajo
				// Al completar con éxito, se devolverá 0. De lo contrario, se devolverá -1
                printf("%s : No existe ese directorio\n", myargv[1]);
            }
            return 0;
        }else{ // otro comando 
            fgProc+=1;
            return command(input, first, last);
        }
	}
	return 0;
}

static char* saltarEspacio(char* s){
	while (isspace(*s)) ++s;
	return s;
}

static void parse(char* cmd){
	cmd = saltarEspacio(cmd);
	char* next = strchr(cmd, ' ');
	int i = 0;

	while(next != NULL) { // Minimo hay un ' '
		next[0] = '\0';
		myargv[i] = cmd;
		++i;
		cmd = saltarEspacio(next + 1);
		next = strchr(cmd, ' ');
	}

	if (cmd[0] != '\0') { // es decir que no esta vacio 
		myargv[i] = cmd; 
		next = strchr(cmd, '\n');
		next[0] = '\0';
		++i;
	}
	myargv[i] = NULL;

	// verifica > y <
	for(int j=0;myargv[j]!=NULL;j++){
		if(strcmp(myargv[j], "<") == 0){
			isInDir = 1;
			rPos = j;
			break;
		}else{
			isInDir = 0;
			rPos = -1;
		}
	}
	for(int j=0;myargv[j]!=NULL; j++){
		if(strcmp(myargv[j], ">") == 0){
			isOutDir = 1;
			lPos = j;
			break;
		}else{
			isOutDir = 0;
			lPos = -1;
		}
	}
}

// controlador de señal para Ctrl + C
void sigint_handler(int sig){
	printf(" Terminando a través del controlador de señal\n");
	exit(0);
}
// controlador de señal para salida hijo
void child_exit(){
	pid_t cpid;
	while(1){
		cpid = waitpid(-1, NULL, WNOHANG); 
		// lo que  significa  que  espera  por  cualquier  proceso  hijo;  este  es  el  mismo comportamiento que tiene wait.
		// WNOHANG Regrese de inmediato si ningún hijo ha terminado.
		if (cpid == 0)
			return;
		else if (cpid == -1)
			return;
		else{
			printf ("Processo %d terminado.\n", cpid);
		}
	}
}

static int command(int input, int first, int last){
	FILE* fd;
	int command_pipe[2];
	/* Invocar tubería */
	pipe( command_pipe ); // pipe (int fds [lector,escritor]); -> 0,1
	pid = fork();

	if (pid == 0){ // en el proceso hijo
		if (first == 1 && last == 0 && input == 0) { // primer comando
			if((isInDir) || (isOutDir)){ // si hay < o >
				if(isInDir){ // <, lo que ocurre es que obtiene datos a partir de un archivo
                    dup2(command_pipe[WRITE], STDOUT_FILENO ); // int dup2 (int oldfd, int newfd);
					// STDOUT_FILENO es un descriptor de archivo entero (en realidad, el entero 1).
                    // Dup2 duplica command_pipe, es decir que manda a la salida estandar lo que se se que tenga la tuberia 
					close(STDIN_FILENO);
                    fd = fopen(myargv[rPos+1],"r"); // se va a leer 
                    myargv[rPos] = NULL; // eliminamos el "<"
                }else{  // >, lo que ocurre es que manda los resultados de un comando a un archivo, que siempre sera la salida estandar
                    dup2( command_pipe[WRITE], STDOUT_FILENO );
					close(STDOUT_FILENO);
                    fd = fopen(myargv[lPos+1],"w"); // se va abrir el descriptor de archivo de salida que sera el lPos
                    myargv[lPos] = NULL; // eliminamos el ">"
                }
			}else{ // No hay redireccionamientos
				dup2(command_pipe[WRITE], STDOUT_FILENO);  // la entrada sera la entrada entandar en duplicidad de descriptor
			}
		} else if (first == 0 && last == 0 && input != 0) { // Comandos medios, es decir no es el primero ni el ultimo
			dup2(input, STDIN_FILENO); // duplicar descriptor, la entrada estandar ahora vendra de input
			dup2(command_pipe[WRITE], STDOUT_FILENO); // ahora en la duplicidad de c_p[write] se escribira la salida estandar
		}else{
			dup2(input, STDIN_FILENO); // ahora en la duplicidad de input se leera la entrada estandar
		}

		execvp( myargv[0], myargv); // nombre del archivo a ejecutar, matriz de cadenas de caracteres
		printf("Comando no encontrado: ¿quiso decir algo más?\n");
		exit(0);
	}
	if (input != 0)
		close(input);

	// Nada más necesita ser escrito
	close(command_pipe[WRITE]);

	// Si es el último comando, no necesita leer nada más
	if (last == 1){
		close(command_pipe[READ]);
	}
	return command_pipe[READ]; // regresamos el command_pipe en lectura
}

static void waitEnd(){ /*Espera a que se complete todo el proceso de primer plano.*/
	int i;
	for(int i=0;i<fgProc;i++)
		wait(NULL); // solo espera a que finalice cualquier hijo.
}